package dev.gallon.fabric;

import dev.gallon.HorseStatsMod;
import dev.gallon.domain.ModConfig;
import dev.gallon.fabric.config.TheModConfig;
import dev.gallon.mixins.AbstractContainerScreenAccessor;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.JanksonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1496;
import net.minecraft.class_491;

public final class HorseStatsModFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AutoConfig.register(TheModConfig.class, JanksonConfigSerializer::new);
        ModConfig config = AutoConfig.getConfigHolder(TheModConfig.class).get().modConfig;
        HorseStatsMod horseStatsMod = new HorseStatsMod(config);

        ScreenEvents.BEFORE_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_491) {
                ScreenEvents.afterRender(screen).register((horseScreen, guiGraphics, mouseX, mouseY, tickDelta) -> {
                    guiGraphics.method_51448().translate(
                            ((AbstractContainerScreenAccessor) horseScreen).getLeftPos(),
                            ((AbstractContainerScreenAccessor) horseScreen).getTopPos()
                    );

                    horseStatsMod.onRenderHorseContainerEvent(
                            (class_491) horseScreen,
                            guiGraphics,
                            mouseX,
                            mouseY
                    );

                    guiGraphics.method_51448().translate(
                            -((AbstractContainerScreenAccessor) horseScreen).getLeftPos(),
                            -((AbstractContainerScreenAccessor) horseScreen).getTopPos()
                    );
                });
            }
        });

        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()
                    && hand == class_1268.field_5808
                    && entity instanceof class_1496 horse) {

                horseStatsMod.onHorseInteractEvent(player, horse);
            }
            return class_1269.field_5811;
        });
    }
}
